
const msg = {
userString: `Hello %1, What a beautiful day. Server current date and time is: `,
failWrite: `Failed to write to file`,
successWrite: `Successfully wrote to file!`,
missingText: "Missing 'text' query parameter.",
missingFilename: "Filename missing.",
errorReadingFile: "404! Error reading or does not exist."
};
exports.msg = msg;