function getDate(){
    return Date();
}; exports.date = getDate;