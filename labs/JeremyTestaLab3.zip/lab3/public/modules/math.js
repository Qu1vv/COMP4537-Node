
const add = function(one, two) {
    let total = one + two;
    return total;
}; 
exports.add = add;

const sub = function(one, two) {
    let total = one - two;
    return total;
}; 
exports.sub = sub;